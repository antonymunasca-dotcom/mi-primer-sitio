const API='https://pokeapi.co/api/v2';
const RANGES={all:[1,1025],kanto:[1,151],johto:[152,251],hoenn:[252,386],sinnoh:[387,493],unova:[494,649],kalos:[650,721],alola:[722,809],galar:[810,898],hisui:[899,905],paldea:[906,1025]};
const TYPES=[['normal','⚪','Normal','#e7dfd5'],['fire','🔥','Fuego','#ffd6c6'],['water','💧','Agua','#cce4ff'],['grass','🌿','Planta','#c9f3d7'],['electric','⚡','Eléctrico','#fff0a6'],['ice','❄️','Hielo','#d5f7fa'],['fighting','🥊','Lucha','#ffd3df'],['poison','☠️','Veneno','#ead5ff'],['ground','🏜️','Tierra','#ffe2b5'],['flying','🪽','Volador','#dce4ff'],['psychic','🔮','Psíquico','#ffcde8'],['bug','🐛','Bicho','#e4f7ad'],['rock','🪨','Roca','#e5dfd2'],['ghost','👻','Fantasma','#ded5ff'],['dragon','🐉','Dragón','#d6d9ff'],['dark','🌑','Siniestro','#d9d1d8'],['steel','⚙️','Acero','#d8e2ed'],['fairy','🧚','Hada','#ffd8ec']];
const $=s=>document.querySelector(s), grid=$('#grid'), statusBox=$('#status');
const typeInfo=Object.fromEntries(TYPES.map(t=>[t[0],t]));
let pokemon=[],region='all',type='all',limit=30;
const favorites=new Set(JSON.parse(localStorage.getItem('pokedex-favorites')||'[]'));
function cap(s){return s?s[0].toUpperCase()+s.slice(1):''}
function setStatus(s){statusBox.textContent=s}
function setupTypes(){TYPES.forEach(([id,emoji,name,color])=>{let b=document.createElement('button');b.className='chip';b.dataset.type=id;b.textContent=emoji+' '+name;b.style.background=color;$('#types').appendChild(b)})}
function render(){
 let q=$('#search').value.trim().toLowerCase(),[min,max]=RANGES[region];let list=pokemon.filter(p=>p.id>=min&&p.id<=max);
 if(type!=='all')list=list.filter(p=>p.types.includes(type));
 if($('#fav-only').checked)list=list.filter(p=>favorites.has(p.id));
 if(q)list=list.filter(p=>p.name.includes(q)||String(p.id)===q.replace(/^#/,''));
 const sort=$('#sort').value;if(sort==='name')list.sort((a,b)=>a.name.localeCompare(b.name));else if(sort==='desc')list.sort((a,b)=>b.name.localeCompare(a.name));else list.sort((a,b)=>a.id-b.id);
 grid.replaceChildren();list.slice(0,limit).forEach(p=>{
  let card=document.createElement('article');card.className='card';card.style.background=`linear-gradient(145deg,${typeInfo[p.types[0]]?.[3]||'#e1f8e9'},#f8efff)`;
  let badges=p.types.map(t=>`<span class="badge" style="background:${typeInfo[t]?.[3]||'#eee'}">${typeInfo[t]?.[2]||cap(t)}</span>`).join('');
  card.innerHTML=`<span class="num">#${String(p.id).padStart(4,'0')}</span><img loading="lazy" src="${p.image}" alt="${cap(p.name)}"><h3>${cap(p.name)}</h3><div class="badges">${badges}</div><div class="actions"><button class="details" data-detail="${p.id}">Detalles</button><button class="heart ${favorites.has(p.id)?'saved':''}" data-heart="${p.id}" aria-label="Favorito">${favorites.has(p.id)?'♥':'♡'}</button></div>`;
  grid.appendChild(card);
 });
 $('#count').textContent=`Mostrando ${Math.min(limit,list.length)} de ${list.length} Pokémon 💜`;
 $('#more').hidden=limit>=list.length;
 if(!list.length)setStatus('No se encontraron Pokémon. Prueba otra búsqueda o filtro.');else setStatus('');
}
async function load(){
 setStatus('Cargando Pokémon desde PokéAPI…');
 try{
  let r=await fetch(`${API}/pokemon?limit=1025`);if(!r.ok)throw Error();let d=await r.json();
  pokemon=d.results.map((p,i)=>({id:i+1,name:p.name,types:[],image:`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i+1}.png`,url:p.url}));
  // Los tipos se cargan en grupos para habilitar el filtro por tipo.
  for(let i=0;i<pokemon.length;i+=50){
   await Promise.all(pokemon.slice(i,i+50).map(async p=>{try{let r=await fetch(p.url),d=await r.json();p.types=d.types.map(t=>t.type.name);p.image=d.sprites.other?.['official-artwork']?.front_default||d.sprites.front_default||p.image}catch(e){}}));
   if(i===0)render();
  }
  render();
 }catch(e){setStatus('No se pudieron cargar los datos. Revisa tu conexión a Internet y vuelve a intentar.')}
}
async function details(id){
 let p=pokemon.find(x=>x.id===Number(id));if(!p)return;let box=$('#detail');box.innerHTML='<p>Consultando datos…</p>';$('#modal').showModal();
 try{
  let r=await fetch(`${API}/pokemon/${id}`);if(!r.ok)throw Error();let d=await r.json();
  let stats=d.stats.map(s=>`<div class="stat"><small>${cap(s.stat.name.replace('-',' '))}</small>${s.base_stat}</div>`).join('');
  let abilities=d.abilities.map(a=>cap(a.ability.name.replace('-',' '))).join(', ');
  box.innerHTML=`<div class="detail"><img src="${d.sprites.other?.['official-artwork']?.front_default||d.sprites.front_default}" alt="${cap(d.name)}"><h2>${cap(d.name)} #${String(d.id).padStart(4,'0')}</h2><div class="badges">${d.types.map(t=>`<span class="badge" style="background:${typeInfo[t.type.name]?.[3]||'#eee'}">${typeInfo[t.type.name]?.[2]||t.type.name}</span>`).join('')}</div><div class="stats"><div class="stat"><small>Altura</small>${d.height/10} m</div><div class="stat"><small>Peso</small>${d.weight/10} kg</div><div class="stat"><small>Experiencia base</small>${d.base_experience??'—'}</div><div class="stat"><small>Habilidades</small>${abilities}</div></div><h3>Estadísticas</h3><div class="stats">${stats}</div></div>`;
 }catch(e){box.textContent='No se pudieron cargar los detalles. Comprueba tu conexión.'}
}
setupTypes();load();
$('#search-form').addEventListener('submit',e=>{e.preventDefault();limit=1025;render()});
$('#search').addEventListener('input',()=>{limit=30;render()});
$('#clear').addEventListener('click',()=>{$('#search').value='';limit=30;render()});
$('#sort').addEventListener('change',render);$('#fav-only').addEventListener('change',render);
$('#types').addEventListener('click',e=>{let b=e.target.closest('[data-type]');if(!b)return;type=b.dataset.type;document.querySelectorAll('.chip').forEach(x=>x.classList.toggle('selected',x===b));limit=30;render()});
$('.panel').addEventListener('click',e=>{let b=e.target.closest('[data-region]');if(!b)return;region=b.dataset.region;document.querySelectorAll('.region').forEach(x=>x.classList.toggle('active',x===b));limit=30;render()});
grid.addEventListener('click',e=>{let d=e.target.closest('[data-detail]'),h=e.target.closest('[data-heart]');if(d)details(d.dataset.detail);if(h){let id=Number(h.dataset.heart);favorites.has(id)?favorites.delete(id):favorites.add(id);localStorage.setItem('pokedex-favorites',JSON.stringify([...favorites]));render()}});
$('#more').addEventListener('click',()=>{limit+=30;render()});$('#close').addEventListener('click',()=>$('#modal').close());$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))$('#modal').close()});